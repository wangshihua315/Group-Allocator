const express = require('express');
const path = require('path');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const Database = require('better-sqlite3');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// DB Setup
const db = new Database(path.join(__dirname, 'app.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE,
  phone TEXT UNIQUE,
  name TEXT,
  username TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
`);

// Create classes and students tables
db.exec(`
CREATE TABLE IF NOT EXISTS classes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS saved_groupings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  class_id INTEGER NOT NULL,
  class_name TEXT NOT NULL,
  group_count INTEGER NOT NULL,
  grouping_data TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_classes_user_id ON classes(user_id);
CREATE INDEX IF NOT EXISTS idx_students_class_id ON students(class_id);
CREATE INDEX IF NOT EXISTS idx_saved_groupings_user_id ON saved_groupings(user_id);
CREATE INDEX IF NOT EXISTS idx_saved_groupings_class_id ON saved_groupings(class_id);
`);

// Migrate: add username column if missing (for existing databases created earlier)
try {
  const row = db.prepare("SELECT COUNT(1) AS count FROM pragma_table_info('users') WHERE name = 'username'").get();
  if (!row || !row.count) {
    db.exec("ALTER TABLE users ADD COLUMN username TEXT;");
    db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username);");
  }
} catch (e) {
  // ignore if already exists; log for visibility in development
  console.warn('Migration check error (safe to ignore if column exists):', e.message);
}

// Helpers
function createToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, phone: user.phone, name: user.name, username: user.username },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// API Routes
app.post('/api/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: '缺少username或password' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (existing) {
      return res.status(409).json({ error: '用户名已被注册' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const result = db.prepare(
      'INSERT INTO users (username, password_hash) VALUES (?, ?)'
    ).run(username, passwordHash);

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
    const token = createToken(user);
    return res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    console.error('Register error', err);
    return res.status(500).json({ error: '服务器错误' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: '缺少username或password' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user) return res.status(401).json({ error: '用户不存在' });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: '密码错误' });

    const token = createToken(user);
    return res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    console.error('Login error', err);
    return res.status(500).json({ error: '服务器错误' });
  }
});

app.get('/api/profile', authMiddleware, (req, res) => {
  const user = db.prepare('SELECT id, username, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: '未找到用户' });
  return res.json({ user });
});

app.put('/api/change-password', authMiddleware, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: '请提供当前密码和新密码' });
    }
    
    if (newPassword.length < 6) {
      return res.status(400).json({ error: '新密码长度至少6位' });
    }
    
    // Get current user with password hash
    const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }
    
    // Verify current password
    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password_hash);
    if (!isCurrentPasswordValid) {
      return res.status(401).json({ error: '当前密码错误' });
    }
    
    // Hash new password
    const newPasswordHash = await bcrypt.hash(newPassword, 10);
    
    // Update password
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newPasswordHash, req.user.id);
    
    res.json({ message: '密码修改成功' });
  } catch (err) {
    console.error('Change password error', err);
    res.status(500).json({ error: '修改密码失败' });
  }
});

// Class management API routes
app.get('/api/classes', authMiddleware, (req, res) => {
  try {
    // Get all classes for the user
    const classes = db.prepare('SELECT id, name, created_at FROM classes WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
    
    // Get students for each class
    const formattedClasses = classes.map(cls => {
      const students = db.prepare('SELECT id, name FROM students WHERE class_id = ? ORDER BY created_at').all(cls.id);
      return {
        ...cls,
        students: students
      };
    });
    
    res.json(formattedClasses);
  } catch (err) {
    console.error('Get classes error', err);
    res.status(500).json({ error: '获取班级列表失败' });
  }
});

app.post('/api/classes', authMiddleware, async (req, res) => {
  try {
    const { name, students } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: '班级名称不能为空' });
    }
    
    // Check if class name already exists for this user
    const existing = db.prepare('SELECT id FROM classes WHERE user_id = ? AND name = ?').get(req.user.id, name);
    if (existing) {
      return res.status(409).json({ error: '班级名称已存在' });
    }
    
    // Create class
    const result = db.prepare('INSERT INTO classes (user_id, name) VALUES (?, ?)').run(req.user.id, name);
    const classId = result.lastInsertRowid;
    
    // Add students if provided
    if (students && Array.isArray(students)) {
      const insertStudent = db.prepare('INSERT INTO students (class_id, name) VALUES (?, ?)');
      for (const student of students) {
        if (student.name && student.name.trim()) {
          insertStudent.run(classId, student.name.trim());
        }
      }
    }
    
    res.json({ id: classId, name, message: '班级创建成功' });
  } catch (err) {
    console.error('Create class error', err);
    res.status(500).json({ error: '创建班级失败' });
  }
});

app.put('/api/classes/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, students } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: '班级名称不能为空' });
    }
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Check if new name conflicts with other classes
    const nameConflict = db.prepare('SELECT id FROM classes WHERE user_id = ? AND name = ? AND id != ?').get(req.user.id, name, id);
    if (nameConflict) {
      return res.status(409).json({ error: '班级名称已存在' });
    }
    
    // Update class name
    db.prepare('UPDATE classes SET name = ? WHERE id = ?').run(name, id);
    
    // Update students
    if (students && Array.isArray(students)) {
      // Remove existing students
      db.prepare('DELETE FROM students WHERE class_id = ?').run(id);
      
      // Add new students
      const insertStudent = db.prepare('INSERT INTO students (class_id, name) VALUES (?, ?)');
      for (const student of students) {
        if (student.name && student.name.trim()) {
          insertStudent.run(id, student.name.trim());
        }
      }
    }
    
    res.json({ message: '班级更新成功' });
  } catch (err) {
    console.error('Update class error', err);
    res.status(500).json({ error: '更新班级失败' });
  }
});

app.delete('/api/classes/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Delete class (students will be deleted due to CASCADE)
    db.prepare('DELETE FROM classes WHERE id = ?').run(id);
    
    res.json({ message: '班级删除成功' });
  } catch (err) {
    console.error('Delete class error', err);
    res.status(500).json({ error: '删除班级失败' });
  }
});

app.post('/api/classes/:id/copy', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: '新班级名称不能为空' });
    }
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Check if new name conflicts
    const nameConflict = db.prepare('SELECT id FROM classes WHERE user_id = ? AND name = ?').get(req.user.id, name);
    if (nameConflict) {
      return res.status(409).json({ error: '班级名称已存在' });
    }
    
    // Get students from original class
    const students = db.prepare('SELECT name FROM students WHERE class_id = ?').all(id);
    
    // Create new class
    const result = db.prepare('INSERT INTO classes (user_id, name) VALUES (?, ?)').run(req.user.id, name);
    const newClassId = result.lastInsertRowid;
    
    // Copy students
    if (students.length > 0) {
      const insertStudent = db.prepare('INSERT INTO students (class_id, name) VALUES (?, ?)');
      for (const student of students) {
        insertStudent.run(newClassId, student.name);
      }
    }
    
    res.json({ id: newClassId, name, message: '班级复制成功' });
  } catch (err) {
    console.error('Copy class error', err);
    res.status(500).json({ error: '复制班级失败' });
  }
});

app.delete('/api/classes/:classId/students/:studentId', authMiddleware, (req, res) => {
  try {
    const { classId, studentId } = req.params;
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(classId, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Delete student
    db.prepare('DELETE FROM students WHERE id = ? AND class_id = ?').run(studentId, classId);
    
    res.json({ message: '学生删除成功' });
  } catch (err) {
    console.error('Delete student error', err);
    res.status(500).json({ error: '删除学生失败' });
  }
});

app.post('/api/classes/:id/random-group', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { groupCount } = req.body;
    
    if (!groupCount || groupCount < 2 || groupCount > 20) {
      return res.status(400).json({ error: '组数必须在2-20之间' });
    }
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Get all students from the class
    const students = db.prepare('SELECT id, name FROM students WHERE class_id = ? ORDER BY RANDOM()').all(id);
    
    if (students.length === 0) {
      return res.status(400).json({ error: '该班级没有学生' });
    }
    
    if (groupCount > students.length) {
      return res.status(400).json({ error: `组数不能超过学生总数(${students.length}人)` });
    }
    
    // Perform random grouping
    const groups = [];
    const shuffledStudents = [...students];
    
    // Fisher-Yates shuffle
    for (let i = shuffledStudents.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffledStudents[i], shuffledStudents[j]] = [shuffledStudents[j], shuffledStudents[i]];
    }
    
    // Calculate students per group
    const studentsPerGroup = Math.floor(students.length / groupCount);
    const remainder = students.length % groupCount;
    
    // Create groups
    let studentIndex = 0;
    for (let i = 0; i < groupCount; i++) {
      // Distribute remainder students to first few groups
      const currentGroupSize = studentsPerGroup + (i < remainder ? 1 : 0);
      const groupStudents = shuffledStudents.slice(studentIndex, studentIndex + currentGroupSize);
      
      groups.push({
        name: `第${i + 1}组`,
        size: groupStudents.length,
        students: groupStudents
      });
      
      studentIndex += currentGroupSize;
    }
    
    res.json(groups);
  } catch (err) {
    console.error('Random grouping error', err);
    res.status(500).json({ error: '随机分组失败' });
  }
});

// Save grouping result
app.post('/api/groupings/save', authMiddleware, (req, res) => {
  try {
    const { classId, className, groupCount, groups } = req.body;
    
    if (!classId || !className || !groupCount || !groups) {
      return res.status(400).json({ error: '缺少必要参数' });
    }
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(classId, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Save grouping
    const result = db.prepare(`
      INSERT INTO saved_groupings (user_id, class_id, class_name, group_count, grouping_data) 
      VALUES (?, ?, ?, ?, ?)
    `).run(req.user.id, classId, className, groupCount, JSON.stringify(groups));
    
    res.json({ 
      id: result.lastInsertRowid, 
      message: '分组保存成功' 
    });
  } catch (err) {
    console.error('Save grouping error', err);
    res.status(500).json({ error: '保存分组失败' });
  }
});

// Get saved groupings for a user
app.get('/api/groupings', authMiddleware, (req, res) => {
  try {
    const groupings = db.prepare(`
      SELECT id, class_id, class_name, group_count, grouping_data, created_at
      FROM saved_groupings 
      WHERE user_id = ? 
      ORDER BY created_at DESC
    `).all(req.user.id);
    
    // Parse grouping data
    const formattedGroupings = groupings.map(grouping => ({
      ...grouping,
      grouping_data: JSON.parse(grouping.grouping_data)
    }));
    
    res.json(formattedGroupings);
  } catch (err) {
    console.error('Get groupings error', err);
    res.status(500).json({ error: '获取历史分组失败' });
  }
});

// Delete a saved grouping
app.delete('/api/groupings/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if grouping belongs to user
    const existing = db.prepare('SELECT id FROM saved_groupings WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '分组记录不存在' });
    }
    
    // Delete grouping
    db.prepare('DELETE FROM saved_groupings WHERE id = ?').run(id);
    
    res.json({ message: '分组记录删除成功' });
  } catch (err) {
    console.error('Delete grouping error', err);
    res.status(500).json({ error: '删除分组记录失败' });
  }
});

// Update a saved grouping
app.put('/api/groupings/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { classId, className, groupCount, groups } = req.body;

    // Ensure this grouping belongs to the user
    const owned = db.prepare('SELECT id FROM saved_groupings WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!owned) {
      return res.status(404).json({ error: '分组记录不存在' });
    }

    // If classId provided, ensure the class also belongs to the user
    if (classId) {
      const classOwned = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(classId, req.user.id);
      if (!classOwned) return res.status(400).json({ error: '班级不存在或不属于当前用户' });
    }

    const payload = {
      class_id: classId || null,
      class_name: className || null,
      group_count: typeof groupCount === 'number' ? groupCount : null,
      grouping_data: groups ? JSON.stringify(groups) : null,
    };

    // Build dynamic update
    const sets = [];
    const params = [];
    if (payload.class_id !== null) { sets.push('class_id = ?'); params.push(payload.class_id); }
    if (payload.class_name !== null) { sets.push('class_name = ?'); params.push(payload.class_name); }
    if (payload.group_count !== null) { sets.push('group_count = ?'); params.push(payload.group_count); }
    if (payload.grouping_data !== null) { sets.push('grouping_data = ?'); params.push(payload.grouping_data); }

    if (sets.length === 0) {
      return res.status(400).json({ error: '没有需要更新的字段' });
    }

    params.push(id);
    db.prepare(`UPDATE saved_groupings SET ${sets.join(', ')} WHERE id = ?`).run(...params);

    res.json({ message: '分组记录已更新' });
  } catch (err) {
    console.error('Update grouping error', err);
    res.status(500).json({ error: '更新分组失败' });
  }
});

// Random drawing API
app.post('/api/classes/:id/draw', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { count, allowRepeat } = req.body;

    const drawCount = parseInt(count, 10);
    const allow = Boolean(allowRepeat);

    if (!drawCount || drawCount < 1 || drawCount > 100) {
      return res.status(400).json({ error: '抽签人数必须在1-100之间' });
    }

    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }

    const students = db.prepare('SELECT id, name FROM students WHERE class_id = ?').all(id);
    if (students.length === 0) {
      return res.status(400).json({ error: '该班级没有学生' });
    }

    if (!allow && drawCount > students.length) {
      return res.status(400).json({ error: `不允许重复时，抽签人数不能超过学生总数(${students.length}人)` });
    }

    let drawnStudents = [];
    if (allow) {
      for (let i = 0; i < drawCount; i++) {
        const idx = Math.floor(Math.random() * students.length);
        drawnStudents.push(students[idx]);
      }
    } else {
      const pool = [...students];
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      drawnStudents = pool.slice(0, drawCount);
    }

    res.json({
      message: `成功抽取${drawCount}人`,
      totalStudents: students.length,
      drawnStudents,
      allowRepeat: allow
    });
  } catch (err) {
    console.error('Random drawing error', err);
    res.status(500).json({ error: '随机抽签失败' });
  }
});

// Static frontend
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});


