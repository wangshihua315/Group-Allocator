const express = require('express');
const path = require('path');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const Database = require('better-sqlite3');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// DB Setup
const db = new Database(path.join(__dirname, 'app.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE,
  phone TEXT UNIQUE,
  name TEXT,
  username TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
`);

// Create classes and students tables
db.exec(`
CREATE TABLE IF NOT EXISTS classes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  enable_gender INTEGER DEFAULT 0,
  enable_ability INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  gender TEXT,
  ability TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS saved_groupings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  class_id INTEGER NOT NULL,
  class_name TEXT NOT NULL,
  group_count INTEGER NOT NULL,
  grouping_data TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_classes_user_id ON classes(user_id);
CREATE INDEX IF NOT EXISTS idx_students_class_id ON students(class_id);
CREATE INDEX IF NOT EXISTS idx_saved_groupings_user_id ON saved_groupings(user_id);
CREATE INDEX IF NOT EXISTS idx_saved_groupings_class_id ON saved_groupings(class_id);
`);

// Migrate: add username column if missing (for existing databases created earlier)
try {
  const row = db.prepare("SELECT COUNT(1) AS count FROM pragma_table_info('users') WHERE name = 'username'").get();
  if (!row || !row.count) {
    db.exec("ALTER TABLE users ADD COLUMN username TEXT;");
    db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username);");
  }
} catch (e) {
  // ignore if already exists; log for visibility in development
  console.warn('Migration check error (safe to ignore if column exists):', e.message);
}

// Migrate: add enable_gender and enable_ability to classes table
try {
  const classRow = db.prepare("SELECT COUNT(1) AS count FROM pragma_table_info('classes') WHERE name = 'enable_gender'").get();
  if (!classRow || !classRow.count) {
    db.exec("ALTER TABLE classes ADD COLUMN enable_gender INTEGER DEFAULT 0;");
  }
} catch (e) {
  console.warn('Migration check error for enable_gender:', e.message);
}

try {
  const abilityRow = db.prepare("SELECT COUNT(1) AS count FROM pragma_table_info('classes') WHERE name = 'enable_ability'").get();
  if (!abilityRow || !abilityRow.count) {
    db.exec("ALTER TABLE classes ADD COLUMN enable_ability INTEGER DEFAULT 0;");
  }
} catch (e) {
  console.warn('Migration check error for enable_ability:', e.message);
}

// Migrate: add gender and ability to students table
try {
  const genderRow = db.prepare("SELECT COUNT(1) AS count FROM pragma_table_info('students') WHERE name = 'gender'").get();
  if (!genderRow || !genderRow.count) {
    db.exec("ALTER TABLE students ADD COLUMN gender TEXT;");
  }
} catch (e) {
  console.warn('Migration check error for gender:', e.message);
}

try {
  const abilityRow = db.prepare("SELECT COUNT(1) AS count FROM pragma_table_info('students') WHERE name = 'ability'").get();
  if (!abilityRow || !abilityRow.count) {
    db.exec("ALTER TABLE students ADD COLUMN ability TEXT;");
  }
} catch (e) {
  console.warn('Migration check error for ability:', e.message);
}

// Helpers
function createToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, phone: user.phone, name: user.name, username: user.username },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// API Routes
app.post('/api/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: '缺少username或password' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (existing) {
      return res.status(409).json({ error: '用户名已被注册' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const result = db.prepare(
      'INSERT INTO users (username, password_hash) VALUES (?, ?)'
    ).run(username, passwordHash);

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
    const token = createToken(user);
    return res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    console.error('Register error', err);
    return res.status(500).json({ error: '服务器错误' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: '缺少username或password' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user) return res.status(401).json({ error: '用户不存在' });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: '密码错误' });

    const token = createToken(user);
    return res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    console.error('Login error', err);
    return res.status(500).json({ error: '服务器错误' });
  }
});

app.get('/api/profile', authMiddleware, (req, res) => {
  const user = db.prepare('SELECT id, username, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: '未找到用户' });
  return res.json({ user });
});

app.put('/api/change-password', authMiddleware, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: '请提供当前密码和新密码' });
    }
    
    if (newPassword.length < 6) {
      return res.status(400).json({ error: '新密码长度至少6位' });
    }
    
    // Get current user with password hash
    const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }
    
    // Verify current password
    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password_hash);
    if (!isCurrentPasswordValid) {
      return res.status(401).json({ error: '当前密码错误' });
    }
    
    // Hash new password
    const newPasswordHash = await bcrypt.hash(newPassword, 10);
    
    // Update password
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newPasswordHash, req.user.id);
    
    res.json({ message: '密码修改成功' });
  } catch (err) {
    console.error('Change password error', err);
    res.status(500).json({ error: '修改密码失败' });
  }
});

// Class management API routes
app.get('/api/classes', authMiddleware, (req, res) => {
  try {
    // Get all classes for the user
    const classes = db.prepare('SELECT id, name, enable_gender, enable_ability, created_at FROM classes WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
    
    // Get students for each class
    const formattedClasses = classes.map(cls => {
      const students = db.prepare('SELECT id, name, gender, ability FROM students WHERE class_id = ? ORDER BY created_at').all(cls.id);
      return {
        ...cls,
        enable_gender: cls.enable_gender === 1,
        enable_ability: cls.enable_ability === 1,
        students: students
      };
    });
    
    res.json(formattedClasses);
  } catch (err) {
    console.error('Get classes error', err);
    res.status(500).json({ error: '获取班级列表失败' });
  }
});

app.post('/api/classes', authMiddleware, async (req, res) => {
  try {
    const { name, students, enable_gender, enable_ability } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: '班级名称不能为空' });
    }
    
    // Check if class name already exists for this user
    const existing = db.prepare('SELECT id FROM classes WHERE user_id = ? AND name = ?').get(req.user.id, name);
    if (existing) {
      return res.status(409).json({ error: '班级名称已存在' });
    }
    
    // Create class with enable_gender and enable_ability
    const enableGender = enable_gender ? 1 : 0;
    const enableAbility = enable_ability ? 1 : 0;
    const result = db.prepare('INSERT INTO classes (user_id, name, enable_gender, enable_ability) VALUES (?, ?, ?, ?)').run(req.user.id, name, enableGender, enableAbility);
    const classId = result.lastInsertRowid;
    
    // Add students if provided
    if (students && Array.isArray(students)) {
      const insertStudent = db.prepare('INSERT INTO students (class_id, name, gender, ability) VALUES (?, ?, ?, ?)');
      for (const student of students) {
        if (student.name && student.name.trim()) {
          insertStudent.run(classId, student.name.trim(), student.gender || null, student.ability || null);
        }
      }
    }
    
    res.json({ id: classId, name, message: '班级创建成功' });
  } catch (err) {
    console.error('Create class error', err);
    res.status(500).json({ error: '创建班级失败' });
  }
});

app.put('/api/classes/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, students, enable_gender, enable_ability } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: '班级名称不能为空' });
    }
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Check if new name conflicts with other classes
    const nameConflict = db.prepare('SELECT id FROM classes WHERE user_id = ? AND name = ? AND id != ?').get(req.user.id, name, id);
    if (nameConflict) {
      return res.status(409).json({ error: '班级名称已存在' });
    }
    
    // Update class name and options
    const enableGender = enable_gender !== undefined ? (enable_gender ? 1 : 0) : null;
    const enableAbility = enable_ability !== undefined ? (enable_ability ? 1 : 0) : null;
    
    if (enableGender !== null && enableAbility !== null) {
      db.prepare('UPDATE classes SET name = ?, enable_gender = ?, enable_ability = ? WHERE id = ?').run(name, enableGender, enableAbility, id);
    } else if (enableGender !== null) {
      db.prepare('UPDATE classes SET name = ?, enable_gender = ? WHERE id = ?').run(name, enableGender, id);
    } else if (enableAbility !== null) {
      db.prepare('UPDATE classes SET name = ?, enable_ability = ? WHERE id = ?').run(name, enableAbility, id);
    } else {
      db.prepare('UPDATE classes SET name = ? WHERE id = ?').run(name, id);
    }
    
    // Update students
    if (students && Array.isArray(students)) {
      // Remove existing students
      db.prepare('DELETE FROM students WHERE class_id = ?').run(id);
      
      // Add new students
      const insertStudent = db.prepare('INSERT INTO students (class_id, name, gender, ability) VALUES (?, ?, ?, ?)');
      for (const student of students) {
        if (student.name && student.name.trim()) {
          insertStudent.run(id, student.name.trim(), student.gender || null, student.ability || null);
        }
      }
    }
    
    res.json({ message: '班级更新成功' });
  } catch (err) {
    console.error('Update class error', err);
    res.status(500).json({ error: '更新班级失败' });
  }
});

app.delete('/api/classes/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Delete class (students will be deleted due to CASCADE)
    db.prepare('DELETE FROM classes WHERE id = ?').run(id);
    
    res.json({ message: '班级删除成功' });
  } catch (err) {
    console.error('Delete class error', err);
    res.status(500).json({ error: '删除班级失败' });
  }
});

app.post('/api/classes/:id/copy', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: '新班级名称不能为空' });
    }
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id, enable_gender, enable_ability FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Check if new name conflicts
    const nameConflict = db.prepare('SELECT id FROM classes WHERE user_id = ? AND name = ?').get(req.user.id, name);
    if (nameConflict) {
      return res.status(409).json({ error: '班级名称已存在' });
    }
    
    // Get students from original class with gender and ability
    const students = db.prepare('SELECT name, gender, ability FROM students WHERE class_id = ?').all(id);
    
    // Create new class with same enable_gender and enable_ability
    const result = db.prepare('INSERT INTO classes (user_id, name, enable_gender, enable_ability) VALUES (?, ?, ?, ?)').run(
      req.user.id, 
      name, 
      existing.enable_gender, 
      existing.enable_ability
    );
    const newClassId = result.lastInsertRowid;
    
    // Copy students with gender and ability
    if (students.length > 0) {
      const insertStudent = db.prepare('INSERT INTO students (class_id, name, gender, ability) VALUES (?, ?, ?, ?)');
      for (const student of students) {
        insertStudent.run(newClassId, student.name, student.gender || null, student.ability || null);
      }
    }
    
    res.json({ id: newClassId, name, message: '班级复制成功' });
  } catch (err) {
    console.error('Copy class error', err);
    res.status(500).json({ error: '复制班级失败' });
  }
});

app.delete('/api/classes/:classId/students/:studentId', authMiddleware, (req, res) => {
  try {
    const { classId, studentId } = req.params;
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(classId, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Delete student
    db.prepare('DELETE FROM students WHERE id = ? AND class_id = ?').run(studentId, classId);
    
    res.json({ message: '学生删除成功' });
  } catch (err) {
    console.error('Delete student error', err);
    res.status(500).json({ error: '删除学生失败' });
  }
});

// Helper functions for intelligent grouping algorithm
function abilityRank(ability) {
  if (ability === '高') return 3;
  if (ability === '中') return 2;
  return 1; // '低' or others
}

function abilityClose(a, b) {
  return Math.abs(abilityRank(a) - abilityRank(b)) <= 1;
}

function genderRatio(group) {
  let m = 0, f = 0;
  group.forEach(student => {
    if (student.gender === '男') m++;
    else if (student.gender === '女') f++;
  });
  const total = Math.max(1, m + f);
  return { mRatio: m / total, fRatio: f / total };
}

// Gender balance adjustment
function adjustGenderBalance(groups) {
  const g = groups.length;
  const steps = Math.floor(g / 2);
  
  for (let step = 0; step < steps; step++) {
    let maxM = 0, maxF = 0;
    let rM = -1, rF = -1;
    
    // Find groups with most males and females
    for (let i = 0; i < g; i++) {
      const { mRatio, fRatio } = genderRatio(groups[i].students);
      if (mRatio > rM) {
        rM = mRatio;
        maxM = i;
      }
      if (fRatio > rF) {
        rF = fRatio;
        maxF = i;
      }
    }
    
    // Try to swap a male from maxM group with a female from maxF group
    let swapped = false;
    for (let i = 0; i < groups[maxM].students.length && !swapped; i++) {
      const sm = groups[maxM].students[i];
      if (sm.gender !== '男') continue;
      
      for (let j = 0; j < groups[maxF].students.length; j++) {
        const sf = groups[maxF].students[j];
        if (sf.gender !== '女') continue;
        
        // Check if abilities are close (difference <= 1)
        const abilityM = sm.ability || '未设置';
        const abilityF = sf.ability || '未设置';
        if (abilityClose(abilityM, abilityF)) {
          // Swap them
          [groups[maxM].students[i], groups[maxF].students[j]] = 
          [groups[maxF].students[j], groups[maxM].students[i]];
          swapped = true;
          break;
        }
      }
    }
    
    if (!swapped) break;
  }
}

// Similar ability grouping: Group students with similar abilities together
// Strategy: Sort by ability (high to low), shuffle same-ability students for randomness,
// then fill groups sequentially so same-ability students are in the same group
function similarAbilityGrouping(students, groupCount) {
  // Separate by ability level
  const high = [];
  const mid = [];
  const low = [];
  const unset = [];
  
  students.forEach(student => {
    const ability = student.ability || '未设置';
    if (ability === '高') {
      high.push(student);
    } else if (ability === '中') {
      mid.push(student);
    } else if (ability === '低') {
      low.push(student);
    } else {
      unset.push(student);
    }
  });
  
  // Shuffle each ability group to ensure different results each time
  [high, mid, low, unset].forEach(group => {
    for (let i = group.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [group[i], group[j]] = [group[j], group[i]];
    }
  });
  
  // Combine: high first, then mid, then low, then unset (ability descending order)
  const sortedStudents = [...high, ...mid, ...low, ...unset];
  
  // Fill groups sequentially: same-ability students go to the same group
  // For example: 9 students (3高3中3低) in 3 groups -> group1 gets all 3高, group2 gets all 3中, group3 gets all 3低
  const groups = [];
  for (let i = 0; i < groupCount; i++) {
    groups.push({ students: [], size: 0 });
  }
  
  // Calculate target size per group
  const targetSize = Math.floor(sortedStudents.length / groupCount);
  const remainder = sortedStudents.length % groupCount;
  
  let currentGroup = 0;
  let studentIndex = 0;
  
  // Fill groups one by one
  for (let g = 0; g < groupCount && studentIndex < sortedStudents.length; g++) {
    // Calculate current group size (add 1 for first 'remainder' groups)
    const currentGroupSize = targetSize + (g < remainder ? 1 : 0);
    
    // Fill this group completely
    for (let i = 0; i < currentGroupSize && studentIndex < sortedStudents.length; i++) {
      groups[g].students.push(sortedStudents[studentIndex++]);
      groups[g].size++;
    }
  }
  
  return groups;
}

// Sequential distribute
function sequentialDistribute(students, groupCount) {
  const n = students.length;
  const baseSize = Math.floor(n / groupCount);
  const rem = n % groupCount;
  
  const groups = [];
  let idx = 0;
  
  for (let i = 0; i < groupCount; i++) {
    const sz = baseSize + (i < rem ? 1 : 0);
    const group = [];
    for (let j = 0; j < sz && idx < n; j++) {
      group.push(students[idx++]);
    }
    groups.push({ students: group, size: group.length });
  }
  
  return groups;
}

// Snake distribute
function snakeDistribute(students, groupCount) {
  const groups = [];
  for (let i = 0; i < groupCount; i++) {
    groups.push({ students: [], size: 0 });
  }
  
  let reverse = false;
  let idx = 0;
  const n = students.length;
  
  while (idx < n) {
    if (!reverse) {
      // Forward: 0, 1, 2, ..., groupCount-1
      for (let i = 0; i < groupCount && idx < n; i++) {
        groups[i].students.push(students[idx++]);
        groups[i].size++;
      }
    } else {
      // Reverse: groupCount-1, groupCount-2, ..., 0
      for (let i = groupCount - 1; i >= 0 && idx < n; i--) {
        groups[i].students.push(students[idx++]);
        groups[i].size++;
      }
    }
    reverse = !reverse;
  }
  
  return groups;
}

app.post('/api/classes/:id/random-group', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { groupCount, genderStrategy = 'random', abilityStrategy = 'random' } = req.body;
    
    if (!groupCount || groupCount < 2 || groupCount > 20) {
      return res.status(400).json({ error: '组数必须在2-20之间' });
    }
    
    // Check if class belongs to user and get class settings
    const classInfo = db.prepare('SELECT id, enable_gender, enable_ability FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!classInfo) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Get all students from the class with gender and ability
    const students = db.prepare('SELECT id, name, gender, ability FROM students WHERE class_id = ?').all(id);
    
    if (students.length === 0) {
      return res.status(400).json({ error: '该班级没有学生' });
    }
    
    if (groupCount > students.length) {
      return res.status(400).json({ error: `组数不能超过学生总数(${students.length}人)` });
    }
    
    // Randomness factor
    const randomness = 0.2;
    
    // Sort students with perturbation
    const sortedStudents = [...students].sort((a, b) => {
      const abilityA = a.ability || '未设置';
      const abilityB = b.ability || '未设置';
      const ra = abilityRank(abilityA) + (Math.random() - 0.5) * randomness;
      const rb = abilityRank(abilityB) + (Math.random() - 0.5) * randomness;
      return rb - ra; // Descending order
    });
    
    // Initialize groups with names
    let groups = [];
    
    // Apply grouping strategy
    if (classInfo.enable_ability && abilityStrategy === 'similar') {
      // Mode 1: Similar ability grouping
      // Groups will have similar ability distribution (not perfectly balanced)
      groups = similarAbilityGrouping(sortedStudents, groupCount);
    } else if (classInfo.enable_ability && abilityStrategy === 'average') {
      // Mode 2: Average ability grouping (snake distribute)
      groups = snakeDistribute(sortedStudents, groupCount);
    } else {
      // Random: Fisher-Yates shuffle
      const shuffledStudents = [...students];
      for (let i = shuffledStudents.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffledStudents[i], shuffledStudents[j]] = [shuffledStudents[j], shuffledStudents[i]];
      }
      groups = sequentialDistribute(shuffledStudents, groupCount);
    }
    
    // Add group names
    groups = groups.map((group, index) => ({
      name: `第${index + 1}组`,
      size: group.size || group.students.length,
      students: group.students || group
    }));
    
    // Gender balance adjustment (if gender is enabled and strategy is average)
    if (classInfo.enable_gender && genderStrategy === 'average') {
      adjustGenderBalance(groups);
    }
    
    res.json(groups);
  } catch (err) {
    console.error('Random grouping error', err);
    res.status(500).json({ error: '随机分组失败' });
  }
});

// Save grouping result
app.post('/api/groupings/save', authMiddleware, (req, res) => {
  try {
    const { classId, className, groupCount, groups } = req.body;
    
    if (!classId || !className || !groupCount || !groups) {
      return res.status(400).json({ error: '缺少必要参数' });
    }
    
    // Check if class belongs to user
    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(classId, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }
    
    // Save grouping
    const result = db.prepare(`
      INSERT INTO saved_groupings (user_id, class_id, class_name, group_count, grouping_data) 
      VALUES (?, ?, ?, ?, ?)
    `).run(req.user.id, classId, className, groupCount, JSON.stringify(groups));
    
    res.json({ 
      id: result.lastInsertRowid, 
      message: '分组保存成功' 
    });
  } catch (err) {
    console.error('Save grouping error', err);
    res.status(500).json({ error: '保存分组失败' });
  }
});

// Get saved groupings for a user
app.get('/api/groupings', authMiddleware, (req, res) => {
  try {
    const groupings = db.prepare(`
      SELECT id, class_id, class_name, group_count, grouping_data, created_at
      FROM saved_groupings 
      WHERE user_id = ? 
      ORDER BY created_at DESC
    `).all(req.user.id);
    
    // Parse grouping data
    const formattedGroupings = groupings.map(grouping => ({
      ...grouping,
      grouping_data: JSON.parse(grouping.grouping_data)
    }));
    
    res.json(formattedGroupings);
  } catch (err) {
    console.error('Get groupings error', err);
    res.status(500).json({ error: '获取历史分组失败' });
  }
});

// Delete a saved grouping
app.delete('/api/groupings/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if grouping belongs to user
    const existing = db.prepare('SELECT id FROM saved_groupings WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '分组记录不存在' });
    }
    
    // Delete grouping
    db.prepare('DELETE FROM saved_groupings WHERE id = ?').run(id);
    
    res.json({ message: '分组记录删除成功' });
  } catch (err) {
    console.error('Delete grouping error', err);
    res.status(500).json({ error: '删除分组记录失败' });
  }
});

// Update a saved grouping
app.put('/api/groupings/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { classId, className, groupCount, groups } = req.body;

    // Ensure this grouping belongs to the user
    const owned = db.prepare('SELECT id FROM saved_groupings WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!owned) {
      return res.status(404).json({ error: '分组记录不存在' });
    }

    // If classId provided, ensure the class also belongs to the user
    if (classId) {
      const classOwned = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(classId, req.user.id);
      if (!classOwned) return res.status(400).json({ error: '班级不存在或不属于当前用户' });
    }

    const payload = {
      class_id: classId || null,
      class_name: className || null,
      group_count: typeof groupCount === 'number' ? groupCount : null,
      grouping_data: groups ? JSON.stringify(groups) : null,
    };

    // Build dynamic update
    const sets = [];
    const params = [];
    if (payload.class_id !== null) { sets.push('class_id = ?'); params.push(payload.class_id); }
    if (payload.class_name !== null) { sets.push('class_name = ?'); params.push(payload.class_name); }
    if (payload.group_count !== null) { sets.push('group_count = ?'); params.push(payload.group_count); }
    if (payload.grouping_data !== null) { sets.push('grouping_data = ?'); params.push(payload.grouping_data); }

    if (sets.length === 0) {
      return res.status(400).json({ error: '没有需要更新的字段' });
    }

    params.push(id);
    db.prepare(`UPDATE saved_groupings SET ${sets.join(', ')} WHERE id = ?`).run(...params);

    res.json({ message: '分组记录已更新' });
  } catch (err) {
    console.error('Update grouping error', err);
    res.status(500).json({ error: '更新分组失败' });
  }
});

// Store used students for each class (key: `${userId}:${classId}`, value: Set of student IDs)
const drawingUsedMap = new Map();

// Random drawing API
app.post('/api/classes/:id/draw', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { count, allowRepeat } = req.body;

    const drawCount = parseInt(count, 10);
    const allow = Boolean(allowRepeat);

    if (!drawCount || drawCount < 1 || drawCount > 100) {
      return res.status(400).json({ error: '抽签人数必须在1-100之间' });
    }

    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }

    const students = db.prepare('SELECT id, name FROM students WHERE class_id = ?').all(id);
    if (students.length === 0) {
      return res.status(400).json({ error: '该班级没有学生' });
    }

    const key = `${req.user.id}:${id}`;
    
    if (allow) {
      // Allow repeat: just randomly pick
      let drawnStudents = [];
      for (let i = 0; i < drawCount; i++) {
        const idx = Math.floor(Math.random() * students.length);
        drawnStudents.push(students[idx]);
      }
      
      res.json({
        message: `成功抽取${drawCount}人`,
        totalStudents: students.length,
        drawnStudents,
        allowRepeat: true,
        roundComplete: false
      });
    } else {
      // No repeat: use used array
      let usedSet = drawingUsedMap.get(key);
      if (!usedSet) {
        usedSet = new Set();
        drawingUsedMap.set(key, usedSet);
      }

      // Get available students (not used yet)
      const availableStudents = students.filter(s => !usedSet.has(s.id));
      
      if (availableStudents.length === 0) {
        // All students have been drawn, round is complete
        res.json({
          message: '一轮结束，所有学生都已被抽签',
          totalStudents: students.length,
          drawnStudents: [],
          allowRepeat: false,
          roundComplete: true,
          usedCount: usedSet.size
        });
        return;
      }

      if (drawCount > availableStudents.length) {
        return res.status(400).json({ 
          error: `剩余可用学生数(${availableStudents.length}人)不足，无法抽取${drawCount}人` 
        });
      }

      // Shuffle available students
      const pool = [...availableStudents];
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }

      // Draw students
      const drawnStudents = pool.slice(0, drawCount);
      
      // Mark as used
      drawnStudents.forEach(s => usedSet.add(s.id));

      // Check if round is complete
      const roundComplete = usedSet.size >= students.length;

      res.json({
        message: roundComplete 
          ? '成功抽取，一轮结束！所有学生都已被抽签' 
          : `成功抽取${drawCount}人`,
        totalStudents: students.length,
        drawnStudents,
        allowRepeat: false,
        roundComplete: roundComplete,
        usedCount: usedSet.size,
        remainingCount: students.length - usedSet.size
      });
    }
  } catch (err) {
    console.error('Random drawing error', err);
    res.status(500).json({ error: '随机抽签失败' });
  }
});

// Reset drawing status for a class
app.post('/api/classes/:id/draw/reset', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;

    const existing = db.prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!existing) {
      return res.status(404).json({ error: '班级不存在' });
    }

    const key = `${req.user.id}:${id}`;
    drawingUsedMap.delete(key);

    res.json({ message: '抽签状态已重置' });
  } catch (err) {
    console.error('Reset drawing error', err);
    res.status(500).json({ error: '重置抽签状态失败' });
  }
});

// Static frontend
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
}).on('error', (err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});


